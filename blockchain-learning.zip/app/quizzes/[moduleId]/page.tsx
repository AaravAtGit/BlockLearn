"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, CheckCircle, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"

export default function QuizPage({ params }: { params: { moduleId: string } }) {
  const router = useRouter()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([])
  const [showResults, setShowResults] = useState(false)
  const [earnedTokens, setEarnedTokens] = useState(0)

  // Mock quiz data for the blockchain fundamentals module
  const quiz = {
    title: "Blockchain Fundamentals Quiz",
    description: "Test your knowledge of blockchain basics",
    questions: [
      {
        id: 1,
        question: "What is the primary purpose of blockchain technology?",
        options: [
          { id: "a", text: "To create cryptocurrencies" },
          { id: "b", text: "To provide a secure, decentralized ledger" },
          { id: "c", text: "To replace traditional banking systems" },
          { id: "d", text: "To speed up database operations" },
        ],
        correctAnswer: "b",
      },
      {
        id: 2,
        question: "Which of the following is NOT a characteristic of blockchain?",
        options: [
          { id: "a", text: "Decentralization" },
          { id: "b", text: "Immutability" },
          { id: "c", text: "Centralized control" },
          { id: "d", text: "Transparency" },
        ],
        correctAnswer: "c",
      },
      {
        id: 3,
        question: "What is a block in a blockchain?",
        options: [
          { id: "a", text: "A single transaction" },
          { id: "b", text: "A collection of transactions grouped together" },
          { id: "c", text: "A computer in the network" },
          { id: "d", text: "A security feature" },
        ],
        correctAnswer: "b",
      },
      {
        id: 4,
        question: "What cryptographic technique is commonly used in blockchain to secure transactions?",
        options: [
          { id: "a", text: "Symmetric encryption" },
          { id: "b", text: "Hashing" },
          { id: "c", text: "Steganography" },
          { id: "d", text: "Quantum cryptography" },
        ],
        correctAnswer: "b",
      },
      {
        id: 5,
        question: "What is the consensus mechanism used by Bitcoin?",
        options: [
          { id: "a", text: "Proof of Stake" },
          { id: "b", text: "Proof of Work" },
          { id: "c", text: "Proof of Authority" },
          { id: "d", text: "Delegated Proof of Stake" },
        ],
        correctAnswer: "b",
      },
    ],
  }

  const handleAnswerSelect = (value: string) => {
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = value
    setSelectedAnswers(newAnswers)
  }

  const handleNextQuestion = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      // Calculate results
      const correctAnswers = selectedAnswers.filter(
        (answer, index) => answer === quiz.questions[index].correctAnswer,
      ).length

      // Calculate tokens earned (10 tokens per correct answer)
      const tokens = correctAnswers * 10
      setEarnedTokens(tokens)
      setShowResults(true)
    }
  }

  const handleFinish = () => {
    router.push("/rewards")
  }

  const currentQuestionData = quiz.questions[currentQuestion]
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <Link href="/learn">
          <Button variant="outline" size="sm" className="gap-1">
            <ArrowLeft className="h-4 w-4" />
            Back to Learning
          </Button>
        </Link>
        {!showResults && (
          <div className="text-sm text-gray-500">
            Question {currentQuestion + 1} of {quiz.questions.length}
          </div>
        )}
      </div>

      {!showResults ? (
        <Card className="mx-auto max-w-3xl">
          <CardHeader>
            <CardTitle>{quiz.title}</CardTitle>
            <CardDescription>{quiz.description}</CardDescription>
            <Progress value={progress} className="mt-2 h-2" />
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <h3 className="mb-4 text-xl font-medium">{currentQuestionData.question}</h3>
              <RadioGroup value={selectedAnswers[currentQuestion] || ""} onValueChange={handleAnswerSelect}>
                {currentQuestionData.options.map((option) => (
                  <div
                    key={option.id}
                    className="flex items-center space-x-2 rounded-lg border p-4 transition-colors hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    <RadioGroupItem value={option.id} id={`option-${option.id}`} />
                    <Label htmlFor={`option-${option.id}`} className="flex-grow cursor-pointer">
                      {option.text}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleNextQuestion} disabled={!selectedAnswers[currentQuestion]} className="w-full">
              {currentQuestion < quiz.questions.length - 1 ? "Next Question" : "Submit Quiz"}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <Card className="mx-auto max-w-3xl">
          <CardHeader>
            <CardTitle>Quiz Results</CardTitle>
            <CardDescription>You've completed the Blockchain Fundamentals Quiz</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6 text-center">
              <div className="mb-4 flex justify-center">
                {earnedTokens >= 30 ? (
                  <CheckCircle className="h-16 w-16 text-green-500" />
                ) : (
                  <AlertCircle className="h-16 w-16 text-amber-500" />
                )}
              </div>
              <h3 className="mb-2 text-2xl font-bold">
                {selectedAnswers.filter((answer, index) => answer === quiz.questions[index].correctAnswer).length} out
                of {quiz.questions.length} correct
              </h3>
              <p className="text-gray-500">
                {earnedTokens >= 30
                  ? "Great job! You've demonstrated a solid understanding of blockchain fundamentals."
                  : "You're making progress! Review the material and try again to improve your score."}
              </p>
            </div>

            <div className="rounded-lg bg-gray-50 p-6 dark:bg-gray-800">
              <div className="mb-4 text-center">
                <h4 className="text-xl font-medium">Rewards Earned</h4>
                <div className="mt-2 text-3xl font-bold text-green-600 dark:text-green-500">
                  {earnedTokens} BlockTokens
                </div>
                <p className="mt-1 text-sm text-gray-500">{earnedTokens} tokens have been added to your wallet</p>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleFinish} className="w-full">
              View My Rewards
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
