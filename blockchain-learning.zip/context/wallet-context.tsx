"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface WalletContextType {
  isConnected: boolean
  isConnecting: boolean
  address: string | null
  balance: string
  connect: () => Promise<void>
  disconnect: () => void
}

const WalletContext = createContext<WalletContextType>({
  isConnected: false,
  isConnecting: false,
  address: null,
  balance: "0",
  connect: async () => {},
  disconnect: () => {},
})

export const useWalletContext = () => useContext(WalletContext)

interface WalletProviderProps {
  children: ReactNode
}

export function WalletProvider({ children }: WalletProviderProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [address, setAddress] = useState<string | null>(null)
  const [balance, setBalance] = useState("0")

  // Check if wallet is already connected on mount
  useEffect(() => {
    const checkConnection = async () => {
      try {
        // Check if ethereum object exists
        if (typeof window !== "undefined" && window.ethereum) {
          // Check if already connected
          const accounts = await window.ethereum.request({ method: "eth_accounts" })
          if (accounts && accounts.length > 0) {
            setAddress(accounts[0])
            setIsConnected(true)
            // Get balance
            const balance = await window.ethereum.request({
              method: "eth_getBalance",
              params: [accounts[0], "latest"],
            })
            setBalance(Number.parseInt(balance, 16).toString())
          }
        }
      } catch (error) {
        console.error("Failed to check wallet connection:", error)
      }
    }

    checkConnection()
  }, [])

  // Listen for account changes
  useEffect(() => {
    if (typeof window !== "undefined" && window.ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          // User disconnected
          setIsConnected(false)
          setAddress(null)
          setBalance("0")
        } else {
          // Account changed
          setAddress(accounts[0])
          setIsConnected(true)
        }
      }

      window.ethereum.on("accountsChanged", handleAccountsChanged)

      return () => {
        window.ethereum.removeListener("accountsChanged", handleAccountsChanged)
      }
    }
  }, [])

  const connect = async () => {
    if (typeof window === "undefined" || !window.ethereum) {
      alert("Please install a Web3 wallet like MetaMask to connect")
      return
    }

    setIsConnecting(true)

    try {
      // Request account access
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" })

      // Check if Monad chain is configured, if not add it
      try {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: "0x1657", // Monad Testnet chainId (5719 in decimal)
              chainName: "Monad Testnet",
              nativeCurrency: {
                name: "Monad",
                symbol: "MON",
                decimals: 18,
              },
              rpcUrls: ["https://rpc.testnet.monad.xyz/"],
              blockExplorerUrls: ["https://explorer.testnet.monad.xyz/"],
            },
          ],
        })
      } catch (switchError) {
        console.error("Failed to add or switch to Monad chain:", switchError)
      }

      // Switch to Monad chain
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: "0x1657" }], // Monad Testnet chainId
        })
      } catch (switchError) {
        console.error("Failed to switch to Monad chain:", switchError)
        setIsConnecting(false)
        return
      }

      if (accounts && accounts.length > 0) {
        setAddress(accounts[0])
        setIsConnected(true)

        // Get balance
        const balance = await window.ethereum.request({
          method: "eth_getBalance",
          params: [accounts[0], "latest"],
        })
        setBalance(Number.parseInt(balance, 16).toString())
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error)
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnect = () => {
    setIsConnected(false)
    setAddress(null)
    setBalance("0")
  }

  return (
    <WalletContext.Provider
      value={{
        isConnected,
        isConnecting,
        address,
        balance,
        connect,
        disconnect,
      }}
    >
      {children}
    </WalletContext.Provider>
  )
}
